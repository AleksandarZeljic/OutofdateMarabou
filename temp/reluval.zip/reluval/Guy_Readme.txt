Changes made to the ReluVal code:
- Checked out current version on Jan 2, 2019
- In split.c, reverted to the old interval propagation function, used in the ReluVal paper.
- In split.c, changed MAX_THREAD to 1


This became the "ReluVal pristine" version



Then, fixed the bug:
    input->lower_matrix.data[k] + OUTWARD_ROUND;

      becomes

    input->lower_matrix.data[k] - OUTWARD_ROUND;

In two places in nnet.c

This is the "ReluVal_bugFixed" version.
